﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IndianRail
{
    public static class Constants
    {
        public static string GetSeatAvailabilityUrl = "https://indianrailapi.com/api/v2/SeatAvailability/apikey/GetYourownApiKey/";
        public static string livetrainrunningUrl = "http://indianrailapi.com/api/v2/livetrainstatus/apikey/GetYourownApiKey/";
        public static string pnrcheckUrl = "http://indianrailapi.com/api/v2/PNRCheck/apikey/GetYourownApiKey/";
        public static string stationNameToCodeUrl = "http://indianrailapi.com/api/v2/StationNameToCode/apikey/GetYourownApiKey/";
        public static string trainfareCalculatorUrl = "http://indianrailapi.com/api/v2/TrainFare/apikey/GetYourownApiKey/";
    }
}
