﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace IndianRail
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class FunctionPage : ContentPage
	{
        RestService _restService;
        public FunctionPage ()
		{
			InitializeComponent ();
            _restService = new RestService();
            
		}

        async void GetCode(object sender, EventArgs e)
        {
            StationNameToCode stationCode = await _restService.GetStationCode(GenerateCodeUri(Constants.stationNameToCodeUrl));
            if (stationCode == null)
            {
                await DisplayAlert("Error", stationCode.ResponseCode, "OK");
            }
            else
            {
                await DisplayAlert(stationCode.Station.NameEn, stationCode.Station.StationCode,"OK");
            }
        }
        string GenerateCodeUri(string endpoint)
        {

            string requestUri = endpoint;
            requestUri += $"StationName/{stationName.Text}/";
      
           
            return requestUri;
        }
    }
}