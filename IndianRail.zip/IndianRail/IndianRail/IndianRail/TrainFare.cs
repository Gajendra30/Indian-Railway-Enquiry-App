﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IndianRail
{
    public class TrainFare
    {

   
            public string TrainNumber { get; set; }
            public string TrainName { get; set; }
            public string From { get; set; }
            public string To { get; set; }
            public string Distance { get; set; }
            public string TrainType { get; set; }
            public List<TFare> Fares { get; set; }
            public string Status { get; set; }
            public string ResponseCode { get; set; }
        }

        public class TFare
        {
            public string Name { get; set; }
            public string Code { get; set; }
            public string Fare { get; set; }
        }

    }

