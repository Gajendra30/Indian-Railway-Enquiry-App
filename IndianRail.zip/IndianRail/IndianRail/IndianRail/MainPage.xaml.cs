﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace IndianRail
{
    public partial class MainPage : TabbedPage
    {
        RestService _restService;

        public MainPage()
        {
            InitializeComponent();
            _restService = new RestService();
        }

         async void GetAvailability(object sender, EventArgs e)
        {
            SeatAvailable seatAvailable = await _restService.GetSeatAvailability(GenerateRequestUri(Constants.GetSeatAvailabilityUrl));
            if (seatAvailable==null)
            {
                await DisplayAlert("Error",seatAvailable.ResponseCode, "ok");
            }
            else
            {
                view.IsVisible = true;
                
                trainNumber.Text = seatAvailable.TrainNo;
                source.Text = seatAvailable.From;
                destination.Text = seatAvailable.To;
                quotafield.Text = seatAvailable.Quota;
                List<Availability> available = seatAvailable.Availability;
                mylist.ItemsSource = available;
            }
            
        }
        string GenerateRequestUri(string endpoint)
        {
            var date = dp.Date;
            
            var finaldate =date.ToString("yyyyMMdd");
         
            
            
            string requestUri = endpoint;
            requestUri += $"TrainNumber/{trainNo.Text}/";
            requestUri += $"From/{src.Text}/";
            requestUri += $"To/{des.Text}/";
            requestUri += $"Date/{finaldate}/";
            requestUri += $"Quota/{quota.Text}/";
            requestUri += $"Class/{classCode.Text}/";
            
            return requestUri;
        }

         async void GetStatus(object sender, EventArgs e)
        {
            Pnrstatus status = await _restService.GetPnrStatus(GeneratePNRUri(Constants.pnrcheckUrl));
            if (status == null)
            {
               await DisplayAlert("Error", status.ResponseCode, "OK");
            }
            else
            {
                view1.IsVisible = true;
                
                trainNumber1.Text = status.TrainNumber;
                trainName.Text = status.TrainName;
                jclass.Text = status.JourneyClass;
                src1.Text = status.From;
                dest.Text = status.To;
                jdate.Text = status.JourneyDate;
                List<Passanger> passenger = status.Passangers;
                mylist1.ItemsSource = passenger;
                chart.Text = status.ChatPrepared; 
            }
        }
        string GeneratePNRUri(string endpoint)
        {

            string requestUri = endpoint;
            requestUri += $"PNRNumber/{pnr.Text}/";
            requestUri += $"Route/1/";
            
            return requestUri;
        }

        private void Set(object sender, EventArgs e)
        {
            Navigation.PushAsync(new FeaturePage());
        }

        private void GoTo(object sender, EventArgs e)
        {
            Navigation.PushModalAsync(new FunctionPage());
        }

        private void help(object sender, EventArgs e)
        {
            Navigation.PushModalAsync(new HelpPage());
        }

        async void GetLiveStatus(object sender, EventArgs e)
        {
            RunningStatus runningStatus = await _restService.GetRunningStatus(GenerateRunningStatusUri(Constants.livetrainrunningUrl));
            if (runningStatus == null)
            {
                await DisplayAlert("Error", runningStatus.ResponseCode, "OK");
            }
            else
            {
                
                view3.IsVisible=true;
                List<Trainroute> statuslist = runningStatus.TrainRoute;
                mylist3.ItemsSource = statuslist;
            }
        }
        string GenerateRunningStatusUri(string endpoint)
        {
            var date = datepick.Date;

            var finaldate = date.ToString("yyyyMMdd");
            var requestUri = endpoint;
            requestUri += $"trainnumber/{trainNumberLive.Text}/";
            requestUri += $"date/{finaldate}/";
            return requestUri;
        }
    }
}
