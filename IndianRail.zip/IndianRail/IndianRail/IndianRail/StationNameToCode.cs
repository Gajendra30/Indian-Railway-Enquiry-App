﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IndianRail
{
    public class StationNameToCode
    {
            public string ResponseCode { get; set; }
            public string Status { get; set; }
            public Station Station { get; set; }
            public object Message { get; set; }
        }

        public class Station
        {
            public string NameEn { get; set; }
            public string NameHn { get; set; }
            public string StationCode { get; set; }
            public string Longitude { get; set; }
            public string Latitude { get; set; }
        }

    }

