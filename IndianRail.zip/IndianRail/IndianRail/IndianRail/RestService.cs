﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace IndianRail
{
    public class RestService
    {
        HttpClient _client;


        public RestService()
        {
            _client = new HttpClient();
        }

        public async Task<SeatAvailable> GetSeatAvailability(string query)
        {
            SeatAvailable seatAvailable = null;

            try
            {
                var response = await _client.GetAsync(query);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    seatAvailable = JsonConvert.DeserializeObject<SeatAvailable>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return seatAvailable;

        }
        public async Task<Pnrstatus> GetPnrStatus(string query)
        {
            Pnrstatus status = null;

            try
            {
                var response = await _client.GetAsync(query);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    status = JsonConvert.DeserializeObject<Pnrstatus>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return status;

        }
        public async Task<StationNameToCode> GetStationCode(string query)
        {
            StationNameToCode stationNameToCode = null;

            try
            {
                var response = await _client.GetAsync(query);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    stationNameToCode = JsonConvert.DeserializeObject<StationNameToCode>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return stationNameToCode;

        }
        public async Task<TrainFare> GetFare(string query)
        {
            TrainFare trainfare = null;

            try
            {
                var response = await _client.GetAsync(query);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    trainfare = JsonConvert.DeserializeObject<TrainFare>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return trainfare;

        }
        public async Task<RunningStatus> GetRunningStatus(string query)
        {
            RunningStatus runningStatus = null;

            try
            {
                var response = await _client.GetAsync(query);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    runningStatus = JsonConvert.DeserializeObject<RunningStatus>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return runningStatus;

        }
    }
}
