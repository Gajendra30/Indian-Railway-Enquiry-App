﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IndianRail
{
    public class Pnrstatus
        {
            public string PnrNumber { get; set; }
            public string Status { get; set; }
            public string ResponseCode { get; set; }
            public string TrainNumber { get; set; }
            public string TrainName { get; set; }
            public string JourneyClass { get; set; }
            public string ChatPrepared { get; set; }
            public string From { get; set; }
            public string To { get; set; }
            public string JourneyDate { get; set; }
            public List<Passanger> Passangers { get; set; }
        }

        public class Passanger
        {
            public string Passenger { get; set; }
            public string BookingStatus { get; set; }
            public string CurrentStatus { get; set; }
        }

    }

