﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IndianRail
{
    public class RunningStatus

    {
        public string ResponseCode { get; set; }
        public string StartDate { get; set; }
        public string TrainNumber { get; set; }
        public object CurrentStation { get; set; }
        public List<Trainroute> TrainRoute { get; set; }
        public string Message { get; set; }
    }

    public class Trainroute
    {
        public string SerialNo { get; set; }
        public string StationName { get; set; }
        public string StationCode { get; set; }
        public string Day { get; set; }
        public string ScheduleArrival { get; set; }
        public string ActualArrival { get; set; }
        public string DelayInArrival { get; set; }
        public string ScheduleDeparture { get; set; }
        public string ActualDeparture { get; set; }
        public string DelayInDeparture { get; set; }
    }
}
