﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace IndianRail
{
    public class SeatAvailable
    {
        public string ResponseCode { get; set; }
        public string TrainNo { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string ClassCode { get; set; }
        public string Quota { get; set; }
        public List<Availability> Availability { get; set; }
        public string Message { get; set; }
    }

    public class Availability
    {
        public string JourneyDate { get; set; }

        [JsonProperty("Availability")]
        public string Available { get; set; }
        public string Confirm { get; set; }
    }
}
