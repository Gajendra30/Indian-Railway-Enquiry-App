﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace IndianRail
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class FeaturePage : ContentPage
	{
        RestService _restService;
       
		public FeaturePage ()
		{
			InitializeComponent ();
            _restService = new RestService();
		}

        async void GetTrainFare(object sender, EventArgs e)
        {
            TrainFare trainfare = await _restService.GetFare(GenerateReqUri(Constants.trainfareCalculatorUrl));
            if (trainfare == null)
            {
                await DisplayAlert("Error", trainfare.ResponseCode, "OK");

            }
            else
            {
                view2.IsVisible = true;
                trainNumber2.Text = trainfare.TrainNumber;
                trainName1.Text = trainfare.TrainName;
                traintype.Text = trainfare.TrainType;
                src2.Text = trainfare.From;
                dest1.Text = trainfare.To;
                distance.Text = trainfare.Distance;
                List<TFare> farelist = trainfare.Fares;
                mylist2.ItemsSource = farelist;
            }
        }
        string GenerateReqUri(string endpoint)
        {
            string requestUri = endpoint;
            requestUri += $"TrainNumber/{trainNumber.Text}/";
            requestUri += $"From/{source.Text}/";
            requestUri += $"To/{destination.Text}/";
            requestUri += $"Quota/{quota.Text}/";
            return requestUri;
        }
    }
}